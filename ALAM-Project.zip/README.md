ALAM Family Control Pro v0.1: local UI only. No remote device connection, location tracking or messaging access.
