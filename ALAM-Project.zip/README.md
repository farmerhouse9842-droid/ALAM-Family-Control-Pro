# ALAM Family Control Pro v0.3

This is a consent-based prototype. Two phones sign in using the SAME Firebase email/password account. The Connected Phone must actively opt in to location sharing and manually press the share button. Controller can see device battery, last shared location and request a ring while the connected app is open. No private messages or notifications are collected. No hidden tracking.

## Firebase setup (required)
1. Create a Firebase project, add Android app `com.alam.familycontrol`.
2. Enable Authentication > Email/Password.
3. Create Cloud Firestore and publish the included `firestore.rules` in Firestore > Rules.
4. Download `google-services.json` for this Android app.
5. For GitHub Actions, base64 encode the full JSON bytes and add repository secret `GOOGLE_SERVICES_JSON_BASE64` under Settings > Secrets and variables > Actions. Never commit the JSON to a public repository.
6. Upload `ALAM-Project.zip` and `.github/workflows/build-android.yml` to the repository, then run the workflow.

## Known limits
- No automatic background live location: only manual updates from Connected Phone.
- Ring requests work while the Connected Phone app is open.
- The same account is used for both devices (no QR pairing yet).
- WhatsApp, Messenger, imo and SMS content are NOT captured or remotely mirrored.
- Firebase use may incur charges depending on usage and plan.
- Build has not been verified in a GitHub Actions run.
