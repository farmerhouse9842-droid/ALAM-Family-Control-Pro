# ALAM Family Control Pro v0.5

- Separate Controller and Connected Phone views, Firebase account sign-in and existing Find Phone request.
- Opt-in live location: tap Enable sharing, grant location, then Start live location. Updates about every 15 seconds (10m movement threshold) while Connected Phone activity is visible. Pauses when app leaves foreground. Controller opens last received location in Maps.
- Messaging shortcuts open WhatsApp, Messenger, imo or SMS on the local device. No remote chat access or notification forwarding. WhatsApp linked devices must be set up in WhatsApp itself.
- One-time permissions dashboard. Android may require separate permission screens.
- Build uses the existing Firebase google-services.json secret.

Limitations: No background location service, no guaranteed ring while app closed, no remote message retrieval. APK has not been compiled or tested on devices in this environment.
