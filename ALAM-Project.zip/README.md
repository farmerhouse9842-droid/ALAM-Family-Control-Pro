ALAM Family Control Pro v0.2. Offline starter dashboard only. No remote access or messaging collection.
