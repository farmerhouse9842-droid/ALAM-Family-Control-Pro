package com.alam.familycontrol

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.BatteryManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.util.UUID

class MainActivity : Activity() {
 private val auth by lazy { FirebaseAuth.getInstance() }
 private val db by lazy { FirebaseFirestore.getInstance() }
 private val prefs by lazy { getSharedPreferences("alam_v03",MODE_PRIVATE) }
 private var mode = "Controller"
 private var themeIndex = 0
 private var sharing = false
 private var listener: ListenerRegistration? = null
 private var status = "Sign in on both phones using the same account."
 private var devices: List<Map<String,Any>> = emptyList()
 private val themes = arrayOf(intArrayOf(0xFF080C16.toInt(),0xFF17263E.toInt(),0xFF42C8FF.toInt()),intArrayOf(0xFF0B0B10.toInt(),0xFF272133.toInt(),0xFFBD8BFF.toInt()),intArrayOf(0xFF07150F.toInt(),0xFF163629.toInt(),0xFF65E6A3.toInt()))
 private val names = arrayOf("Ocean Blue", "Royal Violet", "Emerald Green")
 private val deviceId by lazy { prefs.getString("deviceId",null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("deviceId",it).apply() } }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); mode=prefs.getString("mode","Controller")?:"Controller";themeIndex=prefs.getInt("theme",0).coerceIn(0,2);sharing=prefs.getBoolean("sharing",false); if(auth.currentUser!=null) observe(); render() }
 override fun onDestroy(){listener?.remove();super.onDestroy()}
 private fun bg(c:Int)=GradientDrawable().apply{setColor(c);cornerRadius=22f;setStroke(2,0x44FFFFFF)}
 private fun txt(s:String, size:Float=15f, c:Int=Color.WHITE, bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(c);if(bold)setTypeface(null,Typeface.BOLD);setPadding(8,13,8,13)}
 private fun button(s:String,action:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setTextColor(Color.WHITE);background=bg(themes[themeIndex][1]);setOnClickListener{action()}}
 private fun addButton(parent:LinearLayout,s:String,action:()->Unit){parent.addView(button(s,action),LinearLayout.LayoutParams(-1,104).apply{bottomMargin=8})}
 private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
 private fun signIn(){
  val email=EditText(this).apply{hint="Email";inputType=33}
  val password=EditText(this).apply{hint="Password (6+ characters)";inputType=129}
  val box=LinearLayout(this).apply{orientation=1;setPadding(24,8,24,8);addView(email);addView(password)}
  android.app.AlertDialog.Builder(this).setTitle("Secure family account").setView(box)
   .setPositiveButton("Sign in"){_,_-> auth.signInWithEmailAndPassword(email.text.toString().trim(),password.text.toString()).addOnCompleteListener{if(it.isSuccessful){status="Signed in";observe();render()}else toast(it.exception?.localizedMessage?:"Sign in failed")}}
   .setNeutralButton("Create account"){_,_->auth.createUserWithEmailAndPassword(email.text.toString().trim(),password.text.toString()).addOnCompleteListener{if(it.isSuccessful){status="Account created";observe();render()}else toast(it.exception?.localizedMessage?:"Account creation failed")}}
   .setNegativeButton("Cancel",null).show()
 }
 private fun deviceRef()=db.collection("users").document(auth.currentUser!!.uid).collection("devices").document(deviceId)
 private fun updateDevice(withLocation:Boolean=false){
  if(auth.currentUser==null){toast("Sign in first");return}
  val bm=getSystemService(Context.BATTERY_SERVICE) as BatteryManager
  val pct=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
  val fields=hashMapOf<String,Any>("name" to "${Build.MANUFACTURER} ${Build.MODEL}","battery" to pct,"sharing" to sharing,"updated" to System.currentTimeMillis(),"deviceId" to deviceId)
  if(withLocation && sharing){
   if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),41);return}
   val lm=getSystemService(Context.LOCATION_SERVICE) as LocationManager
   try {
    val providers=lm.getProviders(true)
    val loc=providers.mapNotNull{p->try{lm.getLastKnownLocation(p)}catch(_:Exception){null}}.maxByOrNull{it.time}
    if(loc!=null && System.currentTimeMillis()-loc.time<15*60*1000){fields["latitude"]=loc.latitude;fields["longitude"]=loc.longitude;fields["locationTime"]=loc.time}
    else {toast("No recent location fix. Turn on Location, open Maps, then retry.")}
   }catch(e:Exception){toast("Location unavailable: ${e.localizedMessage}")}
  }
  deviceRef().set(fields,com.google.firebase.firestore.SetOptions.merge()).addOnSuccessListener{status="Device status updated";render()}.addOnFailureListener{toast("Sync failed: ${it.localizedMessage}")}
 }
 override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==41 && grantResults.any{it==PackageManager.PERMISSION_GRANTED})updateDevice(true)}
 private fun observe(){
  listener?.remove()
  val u=auth.currentUser?:return
  listener=db.collection("users").document(u.uid).collection("devices").addSnapshotListener{snap,error->
   if(error!=null){status="Sync error: ${error.localizedMessage}";render();return@addSnapshotListener}
   devices=snap?.documents?.mapNotNull{it.data}?:emptyList()
   val me=snap?.documents?.firstOrNull{it.id==deviceId}
   if(me?.getBoolean("ringRequested")==true){
    toast("Find Phone: ring requested")
    try {val tone=android.media.RingtoneManager.getRingtone(this,android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM));tone?.play();android.os.Handler(mainLooper).postDelayed({tone?.stop()},10000)}catch(_:Exception){}
    deviceRef().update("ringRequested",false)
   }
   render()
  }
 }
 private fun render(){
  val t=themes[themeIndex]
  val scroll=ScrollView(this).apply{setBackgroundColor(t[0]);isFillViewport=true}
  val col=LinearLayout(this).apply{orientation=1;setPadding(24,34,24,40)};scroll.addView(col)
  val header=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL}
  val title=LinearLayout(this).apply{orientation=1};title.addView(txt("ALAM",32f,t[2],true));title.addView(txt("FAMILY CONTROL PRO",18f,Color.WHITE,true));header.addView(title,LinearLayout.LayoutParams(0,-2,1f))
  header.addView(ImageView(this).apply{setImageResource(R.drawable.alam_portrait);scaleType=ImageView.ScaleType.CENTER_CROP;background=bg(t[1]);clipToOutline=true;contentDescription="ALAM"},LinearLayout.LayoutParams(106,106));col.addView(header)
  col.addView(txt("v0.3 • Consent-based family devices",12f,0xFFB9C4D2.toInt()))
  col.addView(txt("CHOOSE MODE",14f,t[2],true))
  val row=LinearLayout(this);for(m in listOf("Controller","Connected Phone")){row.addView(button(if(m==mode)"✓ $m" else m){mode=m;prefs.edit().putString("mode",m).apply();render()},LinearLayout.LayoutParams(0,106,1f))};col.addView(row)
  col.addView(txt("CURRENT MODE: $mode",17f,Color.WHITE,true))
  val card=LinearLayout(this).apply{orientation=1;setPadding(16,16,16,16);background=bg(t[1])};col.addView(card)
  if(auth.currentUser==null){card.addView(txt("No account connected",19f,t[2],true));addButton(card,"Sign in / Create account"){signIn()}}
  else {
   card.addView(txt("Account: ${auth.currentUser?.email}",14f,t[2],true))
   if(mode=="Connected Phone"){
    card.addView(txt("This phone: ${Build.MANUFACTURER} ${Build.MODEL}"))
    card.addView(txt("Location sharing: ${if(sharing)"ON (manual updates)" else "OFF"}"))
    addButton(card,if(sharing)"Disable location sharing" else "Enable location sharing"){sharing=!sharing;prefs.edit().putBoolean("sharing",sharing).apply();updateDevice()}
    addButton(card,"Update battery & device status"){updateDevice()}
    addButton(card,"Share current/recent location"){if(sharing)updateDevice(true) else toast("Enable location sharing first")}
    card.addView(txt("Location updates are manual. This app does not run hidden tracking.",12f))
   }else{
    card.addView(txt("Connected devices (${devices.size})",19f,t[2],true))
    if(devices.isEmpty())card.addView(txt("On the other phone, sign in with the same account, choose Connected Phone, and tap Update status."))
    devices.filter{it["deviceId"]!=deviceId}.forEach{device->
     val id=device["deviceId"] as? String ?:return@forEach
     card.addView(txt("${device["name"]?:"Phone"} • Battery ${device["battery"]?:"?"}%",16f,Color.WHITE,true))
     card.addView(txt("Location sharing: ${device["sharing"]?:false} | Last sync: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date((device["updated"] as? Number)?.toLong()?:0))}",12f))
     val lat=(device["latitude"] as? Number)?.toDouble();val lon=(device["longitude"] as? Number)?.toDouble()
     if(device["sharing"]==true && lat!=null && lon!=null){addButton(card,"Open last shared location in Maps"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("geo:$lat,$lon?q=$lat,$lon")))}}
     addButton(card,"Ring this phone (while app is open)"){db.collection("users").document(auth.currentUser!!.uid).collection("devices").document(id).update("ringRequested",true).addOnFailureListener{toast(it.localizedMessage?:"Request failed")}}
    }
   }
   addButton(card,"Sign out"){listener?.remove();listener=null;auth.signOut();devices=emptyList();render()}
  }
  col.addView(txt(status,12f,0xFFB9C4D2.toInt()))
  col.addView(txt("MESSAGING",14f,t[2],true))
  val info=LinearLayout(this).apply{orientation=1;setPadding(16,12,16,12);background=bg(t[1])};col.addView(info)
  info.addView(txt("WhatsApp • Messenger • imo • SMS",16f,Color.WHITE,true))
  info.addView(txt("Private chat and notification forwarding are not enabled in this version. Use each app's own linked-device feature for access to your conversations.",13f))
  col.addView(txt("APPEARANCE",14f,t[2],true))
  names.forEachIndexed{i,n->addButton(col,(if(themeIndex==i)"✓  " else "")+n){themeIndex=i;prefs.edit().putInt("theme",i).apply();render()}}
  col.addView(txt("Privacy: Location sharing is opt-in, updates are manual, and only devices signed in to your account can access shared records. Ring requests require the connected app to be open.",12f,0xFFB9C4D2.toInt()))
  setContentView(scroll)
 }
}
