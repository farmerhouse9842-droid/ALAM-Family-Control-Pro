package com.alam.familycontrol

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.os.BatteryManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import java.util.UUID

class MainActivity : Activity() {
 private val auth by lazy { FirebaseAuth.getInstance() }
 private val db by lazy { FirebaseFirestore.getInstance() }
 private val prefs by lazy { getSharedPreferences("alam_v03",MODE_PRIVATE) }
 private var mode = "Controller"
 private var themeIndex = 0
 private var sharing = false
 private var listener: ListenerRegistration? = null
 private var locationManager: LocationManager? = null
 private var liveListener: android.location.LocationListener? = null
 private var liveActive = false
 private var status = "Sign in on both phones using the same account."
 private var devices: List<Map<String,Any>> = emptyList()
 private val themes = arrayOf(intArrayOf(0xFF080C16.toInt(),0xFF17263E.toInt(),0xFF42C8FF.toInt()),intArrayOf(0xFF0B0B10.toInt(),0xFF272133.toInt(),0xFFBD8BFF.toInt()),intArrayOf(0xFF07150F.toInt(),0xFF163629.toInt(),0xFF65E6A3.toInt()))
 private val names = arrayOf("Ocean Blue", "Royal Violet", "Emerald Green")
 private val deviceId by lazy { prefs.getString("deviceId",null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("deviceId",it).apply() } }
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); mode=prefs.getString("mode","Controller")?:"Controller";themeIndex=prefs.getInt("theme",0).coerceIn(0,2);sharing=prefs.getBoolean("sharing",false); if(auth.currentUser!=null) observe(); render() }
 override fun onPause(){ stopLiveLocation();super.onPause() }
 override fun onResume(){super.onResume(); if(sharing && mode=="Connected Phone" && prefs.getBoolean("liveEnabled",false)) startLiveLocation() }
 override fun onDestroy(){stopLiveLocation();listener?.remove();super.onDestroy()}
 private fun stopLiveLocation(){
  liveListener?.let { listener -> try { locationManager?.removeUpdates(listener) }catch(_:Exception){} }
  liveListener=null;liveActive=false
 }
 private fun startLiveLocation(){
  if(liveActive || !sharing || mode!="Connected Phone" || auth.currentUser==null)return
  if(!hasLocation()){toast("Allow location permission first");return}
  try {
   val lm=getSystemService(Context.LOCATION_SERVICE) as LocationManager
   val provider=when {lm.isProviderEnabled(LocationManager.GPS_PROVIDER)->LocationManager.GPS_PROVIDER;lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)->LocationManager.NETWORK_PROVIDER;else->null}
   if(provider==null){toast("Turn on phone location");return}
   val ll=object:android.location.LocationListener {
    override fun onLocationChanged(loc:android.location.Location){
     if(!sharing || mode!="Connected Phone" || auth.currentUser==null)return
     deviceRef().set(mapOf("latitude" to loc.latitude,"longitude" to loc.longitude,"locationTime" to loc.time,"updated" to System.currentTimeMillis(),"sharing" to true,"mode" to "Connected Phone"),com.google.firebase.firestore.SetOptions.merge())
    }
   }
   lm.requestLocationUpdates(provider,15000L,10f,ll)
   locationManager=lm;liveListener=ll;liveActive=true
  }catch(e:Exception){toast("Live location unavailable: ${e.localizedMessage}")}
 }
 private fun openOwnApp(pkg:String){
  val launch=packageManager.getLaunchIntentForPackage(pkg)
  if(launch!=null)startActivity(launch) else toast("App not installed or unavailable on this phone")
 }
 private fun bg(c:Int)=GradientDrawable().apply{setColor(c);cornerRadius=22f;setStroke(2,0x44FFFFFF)}
 private fun txt(s:String, size:Float=15f, c:Int=Color.WHITE, bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(c);if(bold)setTypeface(null,Typeface.BOLD);setPadding(8,13,8,13)}
 private fun button(s:String,action:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setTextColor(Color.WHITE);background=bg(themes[themeIndex][1]);setOnClickListener{action()}}
 private fun addButton(parent:LinearLayout,s:String,action:()->Unit){parent.addView(button(s,action),LinearLayout.LayoutParams(-1,104).apply{bottomMargin=8})}
 private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
 private fun signIn(){
  val email=EditText(this).apply{hint="Email";inputType=33}
  val password=EditText(this).apply{hint="Password (6+ characters)";inputType=129}
  val box=LinearLayout(this).apply{orientation=1;setPadding(24,8,24,8);addView(email);addView(password)}
  android.app.AlertDialog.Builder(this).setTitle("Secure family account").setView(box)
   .setPositiveButton("Sign in"){_,_-> auth.signInWithEmailAndPassword(email.text.toString().trim(),password.text.toString()).addOnCompleteListener{if(it.isSuccessful){status="Signed in";observe();render()}else toast(it.exception?.localizedMessage?:"Sign in failed")}}
   .setNeutralButton("Create account"){_,_->auth.createUserWithEmailAndPassword(email.text.toString().trim(),password.text.toString()).addOnCompleteListener{if(it.isSuccessful){status="Account created";observe();render()}else toast(it.exception?.localizedMessage?:"Account creation failed")}}
   .setNegativeButton("Cancel",null).show()
 }
 private fun deviceRef()=db.collection("users").document(auth.currentUser!!.uid).collection("devices").document(deviceId)
 private fun updateDevice(withLocation:Boolean=false){
  if(auth.currentUser==null){toast("Sign in first");return}
  val bm=getSystemService(Context.BATTERY_SERVICE) as BatteryManager
  val pct=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
  val fields=hashMapOf<String,Any>("name" to "${Build.MANUFACTURER} ${Build.MODEL}","battery" to pct,"sharing" to sharing,"mode" to mode,"updated" to System.currentTimeMillis(),"deviceId" to deviceId,"mode" to mode)
  if(withLocation && sharing){
   if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),41);return}
   val lm=getSystemService(Context.LOCATION_SERVICE) as LocationManager
   try {
    val providers=lm.getProviders(true)
    val loc=providers.mapNotNull{p->try{lm.getLastKnownLocation(p)}catch(_:Exception){null}}.maxByOrNull{it.time}
    if(loc!=null && System.currentTimeMillis()-loc.time<15*60*1000){fields["latitude"]=loc.latitude;fields["longitude"]=loc.longitude;fields["locationTime"]=loc.time}
    else {toast("No recent location fix. Turn on Location, open Maps, then retry.")}
   }catch(e:Exception){toast("Location unavailable: ${e.localizedMessage}")}
  }
  deviceRef().set(fields,com.google.firebase.firestore.SetOptions.merge()).addOnSuccessListener{status="Device status updated";render()}.addOnFailureListener{toast("Sync failed: ${it.localizedMessage}")}
 }
 override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==41 && grantResults.any{it==PackageManager.PERMISSION_GRANTED}){updateDevice(true);if(prefs.getBoolean("liveEnabled",false))startLiveLocation()}; if(requestCode==42 || requestCode==43)render()}
 private fun hasLocation() = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
 private fun setupPermissions(parent:LinearLayout){
  parent.addView(txt("ONE-TIME PERMISSION SETUP",15f,themes[themeIndex][2],true))
  parent.addView(txt("Android requires separate approval for some permissions. Already granted permissions are not requested again.",12f))
  addButton(parent,if(hasLocation())"✓ Location permission granted" else "1. Allow location"){
   if(!hasLocation())requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),41) else toast("Location already allowed")
  }
  if(Build.VERSION.SDK_INT>=33){
   val allowed=checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED
   addButton(parent,if(allowed)"✓ Notifications allowed" else "2. Allow notifications"){
    if(!allowed)requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),42) else toast("Notifications already allowed")
   }
  }
  if(Build.VERSION.SDK_INT>=29){
   val allowed=checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)==PackageManager.PERMISSION_GRANTED
   addButton(parent,if(allowed)"✓ Background location allowed" else "3. Background location settings"){
    if(!hasLocation())toast("Allow location first") else if(!allowed){
     android.app.AlertDialog.Builder(this).setTitle("Optional background location")
      .setMessage("Only enable if you want location sharing while the app is not on screen. Android may require you to select 'Allow all the time' in app settings. This version still updates location manually.")
      .setPositiveButton("Open settings"){_,_->startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))}
      .setNegativeButton("Cancel",null).show()
    }else toast("Already allowed")
   }
  }
  addButton(parent,"App battery settings (optional)"){
   startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))
  }
 }
 private fun observe(){
  listener?.remove()
  val u=auth.currentUser?:return
  listener=db.collection("users").document(u.uid).collection("devices").addSnapshotListener{snap,error->
   if(error!=null){status="Sync error: ${error.localizedMessage}";render();return@addSnapshotListener}
   devices=snap?.documents?.mapNotNull{it.data}?:emptyList()
   val me=snap?.documents?.firstOrNull{it.id==deviceId}
   if(mode=="Connected Phone" && me?.getBoolean("ringRequested")==true){
    toast("Find Phone: ring requested")
    try {val tone=android.media.RingtoneManager.getRingtone(this,android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM));tone?.play();android.os.Handler(mainLooper).postDelayed({tone?.stop()},10000)}catch(_:Exception){}
    deviceRef().update("ringRequested",false)
   }
   render()
  }
 }
 private fun render(){
  val t=themes[themeIndex]
  val scroll=ScrollView(this).apply{setBackgroundColor(t[0]);isFillViewport=true}
  val col=LinearLayout(this).apply{orientation=1;setPadding(24,34,24,40)};scroll.addView(col)
  val header=LinearLayout(this).apply{orientation=0;gravity=Gravity.CENTER_VERTICAL}
  val title=LinearLayout(this).apply{orientation=1};title.addView(txt("ALAM",32f,t[2],true));title.addView(txt("FAMILY CONTROL PRO",18f,Color.WHITE,true));header.addView(title,LinearLayout.LayoutParams(0,-2,1f))
  header.addView(ImageView(this).apply{setImageResource(R.drawable.alam_portrait);scaleType=ImageView.ScaleType.CENTER_CROP;background=bg(t[1]);clipToOutline=true;contentDescription="ALAM"},LinearLayout.LayoutParams(106,106));col.addView(header)
  col.addView(txt("v0.5 • Consent-based family devices",12f,0xFFB9C4D2.toInt()))
  col.addView(txt("CHOOSE MODE",14f,t[2],true))
  val row=LinearLayout(this);for(m in listOf("Controller","Connected Phone")){row.addView(button(if(m==mode)"✓ $m" else m){stopLiveLocation();mode=m;prefs.edit().putString("mode",m).apply();if(auth.currentUser!=null)updateDevice();if(mode=="Connected Phone" && sharing && prefs.getBoolean("liveEnabled",false))startLiveLocation();render()},LinearLayout.LayoutParams(0,106,1f))};col.addView(row)
  col.addView(txt("CURRENT MODE: $mode",17f,Color.WHITE,true))
  val card=LinearLayout(this).apply{orientation=1;setPadding(16,16,16,16);background=bg(t[1])};col.addView(card)
  if(auth.currentUser==null){card.addView(txt("No account connected",19f,t[2],true));addButton(card,"Sign in / Create account"){signIn()}}
  else {
   card.addView(txt("Account: ${auth.currentUser?.email}",14f,t[2],true))
   if(mode=="Connected Phone"){
    card.addView(txt("This phone: ${Build.MANUFACTURER} ${Build.MODEL}"))
    card.addView(txt("Location sharing: ${if(sharing)"ON (manual updates)" else "OFF"}"))
    addButton(card,if(sharing)"Disable location sharing" else "Enable location sharing"){sharing=!sharing;prefs.edit().putBoolean("sharing",sharing).apply();if(!sharing){stopLiveLocation();prefs.edit().putBoolean("liveEnabled",false).apply()} ;updateDevice();render()}
    addButton(card,"Update battery & device status"){updateDevice()}
    addButton(card,"Share current/recent location"){if(sharing)updateDevice(true) else toast("Enable location sharing first")}
    addButton(card,if(liveActive)"Stop live location" else "Start live location (while app is visible)"){
     if(liveActive){prefs.edit().putBoolean("liveEnabled",false).apply();stopLiveLocation()}
     else if(!sharing)toast("Enable location sharing first")
     else {prefs.edit().putBoolean("liveEnabled",true).apply();startLiveLocation()}
     render()
    }
    card.addView(txt("Live updates run about every 15 seconds while this app is visible. Stop sharing at any time. No hidden background tracking.",12f))
   }else{
    card.addView(txt("Connected phones (${devices.count{it["deviceId"]!=deviceId && it["mode"]=="Connected Phone"}})",19f,t[2],true))
    if(devices.isEmpty())card.addView(txt("On the other phone, sign in with the same account, choose Connected Phone, and tap Update status."))
    devices.filter{it["deviceId"]!=deviceId && it["mode"]=="Connected Phone"}.forEach{device->
     val id=device["deviceId"] as? String ?:return@forEach
     card.addView(txt("${device["name"]?:"Phone"} • Battery ${device["battery"]?:"?"}%",16f,Color.WHITE,true))
     card.addView(txt("Location sharing: ${device["sharing"]?:false} | Last sync: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date((device["updated"] as? Number)?.toLong()?:0))}",12f))
     val lat=(device["latitude"] as? Number)?.toDouble();val lon=(device["longitude"] as? Number)?.toDouble()
     if(device["sharing"]==true && lat!=null && lon!=null){addButton(card,"Open shared location in Maps"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("geo:$lat,$lon?q=$lat,$lon")))}}
     addButton(card,"Ring this phone (while app is open)"){db.collection("users").document(auth.currentUser!!.uid).collection("devices").document(id).update("ringRequested",true).addOnFailureListener{toast(it.localizedMessage?:"Request failed")}}
    }
   }
   addButton(card,"Sign out"){stopLiveLocation();listener?.remove();listener=null;auth.signOut();devices=emptyList();render()}
  }
  col.addView(txt(status,12f,0xFFB9C4D2.toInt()))
  if(mode=="Connected Phone"){
   val permissions=LinearLayout(this).apply{orientation=1;setPadding(16,12,16,12);background=bg(t[1])}
   col.addView(permissions);setupPermissions(permissions)
  }
  col.addView(txt("MESSAGING",14f,t[2],true))
  val info=LinearLayout(this).apply{orientation=1;setPadding(16,12,16,12);background=bg(t[1])};col.addView(info)
  info.addView(txt("WhatsApp • Messenger • imo • SMS",16f,Color.WHITE,true))
  info.addView(txt("Open messaging apps on THIS phone. For your own WhatsApp chats on another phone, use WhatsApp Linked Devices. Private messages are never copied to Firebase.",13f))
  addButton(info,"Open WhatsApp"){openOwnApp("com.whatsapp")}
  addButton(info,"Open Messenger"){openOwnApp("com.facebook.orca")}
  addButton(info,"Open imo"){openOwnApp("com.imo.android.imoim")}
  addButton(info,"Open SMS"){try{startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))}catch(_:Exception){toast("No SMS app available")}}
  col.addView(txt("APPEARANCE",14f,t[2],true))
  names.forEachIndexed{i,n->addButton(col,(if(themeIndex==i)"✓  " else "")+n){themeIndex=i;prefs.edit().putInt("theme",i).apply();render()}}
  col.addView(txt("Privacy: Location sharing is opt-in, live updates run only while app is visible, and only devices signed in to your account can access shared records. Ring requests require the connected app to be open.",12f,0xFFB9C4D2.toInt()))
  setContentView(scroll)
 }
}
