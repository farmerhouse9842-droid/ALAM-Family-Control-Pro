package com.alam.familycontrol

import android.app.Activity
import android.os.Bundle
import android.os.BatteryManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.drawable.BitmapDrawable
import android.graphics.BitmapFactory

class MainActivity : Activity() {
 private var mode = "Controller"
 private var themeIndex = 0
 private val themes = arrayOf(intArrayOf(0xFF080C16.toInt(),0xFF17263E.toInt(),0xFF42C8FF.toInt()),intArrayOf(0xFF0B0B10.toInt(),0xFF272133.toInt(),0xFFBD8BFF.toInt()),intArrayOf(0xFF07150F.toInt(),0xFF163629.toInt(),0xFF65E6A3.toInt()))
 private val names = arrayOf("Ocean Blue", "Royal Violet", "Emerald Green")
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val prefs=getSharedPreferences("settings",MODE_PRIVATE); mode=prefs.getString("mode","Controller")?:"Controller"; themeIndex=prefs.getInt("theme",0).coerceIn(0,2); render() }
 private fun makeBackground(color:Int, radius:Float=22f): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=radius; setStroke(2,0x44FFFFFF) }
 private fun label(text:String, size:Float, color:Int, bold:Boolean=false):TextView = TextView(this).apply { this.text=text; textSize=size; setTextColor(color); if(bold) setTypeface(null,Typeface.BOLD); setPadding(4,12,4,12) }
 private fun render(){
  val t=themes[themeIndex]
  val root=ScrollView(this).apply { setBackgroundColor(t[0]); isFillViewport = true }
  val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,38,24,30) }
  root.addView(content)
  val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
  val heading=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
  heading.addView(label("ALAM",32f,t[2],true))
  heading.addView(label("FAMILY CONTROL PRO",18f,Color.WHITE,true))
  header.addView(heading,LinearLayout.LayoutParams(0,-2,1f))
  val avatar=ImageView(this).apply { setImageResource(com.alam.familycontrol.R.drawable.alam_portrait); scaleType=ImageView.ScaleType.CENTER_CROP; background=makeBackground(t[1],28f); clipToOutline=true; contentDescription="ALAM logo" }
  header.addView(avatar,LinearLayout.LayoutParams(104,104))
  content.addView(header)
  content.addView(label("Version 0.2  •  Consent-first device dashboard",12f,0xFFACB8C8.toInt()))
  content.addView(label("CHOOSE MODE",14f,t[2],true))
  val modes=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
  fun modeButton(value:String):Button = Button(this).apply { text=value; isAllCaps=false; setTextColor(Color.WHITE); background=makeBackground(if(mode==value)t[2] else t[1]); setOnClickListener { mode=value; getSharedPreferences("settings",MODE_PRIVATE).edit().putString("mode",mode).apply(); render() } }
  modes.addView(modeButton("Controller"),LinearLayout.LayoutParams(0,110,1f)); modes.addView(modeButton("Connected Phone"),LinearLayout.LayoutParams(0,110,1f)); content.addView(modes)
  content.addView(label("CURRENT MODE: $mode",17f,Color.WHITE,true))
  val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,20,22,20); background=makeBackground(t[1]) }
  if(mode=="Controller") {
   card.addView(label("Your devices",22f,Color.WHITE,true))
   card.addView(label("No paired devices yet",17f,t[2]))
   card.addView(label("Device pairing and remote features are planned for a later version. This build does not connect to other phones.",14f,0xFFD3DDE9.toInt()))
  } else {
   val bm=getSystemService(Context.BATTERY_SERVICE) as BatteryManager
   val pct=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
   card.addView(label("This phone",22f,Color.WHITE,true))
   card.addView(label("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}",15f,0xFFD3DDE9.toInt()))
   card.addView(label("Battery: ${if(pct in 0..100) "$pct%" else "Unavailable"}",17f,t[2],true))
   card.addView(label("Sharing: OFF",16f,Color.WHITE,true))
   card.addView(label("No location, messages, notifications, or screen content are collected or sent in v0.1.",14f,0xFFD3DDE9.toInt()))
  }
  content.addView(card,LinearLayout.LayoutParams(-1,-2).apply { topMargin=16 })
  content.addView(label("APPEARANCE",14f,t[2],true))
  names.forEachIndexed { i,name -> val b=Button(this).apply { text=(if(themeIndex==i)"✓  " else "")+name; isAllCaps=false; setTextColor(Color.WHITE); background=makeBackground(t[1]); setOnClickListener { themeIndex=i; getSharedPreferences("settings",MODE_PRIVATE).edit().putInt("theme",i).apply(); render() } }; content.addView(b,LinearLayout.LayoutParams(-1,100).apply { bottomMargin=8 }) }
  content.addView(label("Privacy: This starter app has no internet permission and does not read messages or track location.",13f,0xFFACB8C8.toInt()))
  setContentView(root)
 }
}
