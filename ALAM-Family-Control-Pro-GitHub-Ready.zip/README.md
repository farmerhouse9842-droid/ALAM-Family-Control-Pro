# ALAM Family Control Pro v0.1

A consent-first Android starter app with two selectable modes and three premium dark themes.

## Features in this version
- Controller dashboard (placeholder; no remote connection yet)
- Connected Phone dashboard with local device and battery information
- Ocean Blue, Royal Violet, Emerald Green themes
- Mode and theme preference saved locally
- No INTERNET permission; no location, message, notification or screen capture

## Build on GitHub from your phone
1. Create a new GitHub repository.
2. Upload the **contents** of this project folder to the repository root, including `.github/workflows/build-android.yml`.
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Choose **Run workflow** (or push to main to trigger a build).
5. After the run succeeds, open its **Artifacts** section and download `ALAM-Family-Control-Pro-v0.1-debug`.
6. Unzip it and install `app-debug.apk` on your Android phone. Android may ask you to permit installing apps from your file manager.

Debug APK is for personal testing. Future device pairing should use visible opt-in consent, encrypted authentication and revocable permissions.
